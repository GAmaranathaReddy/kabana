import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kanban-view',
  templateUrl: './kanban-view.component.html',
  styleUrls: ['./kanban-view.component.css']
})
export class KanbanViewComponent implements OnInit {
  name: string = '';
  taskForward: string ='';
  selectedStage: any = 0;
  isForwardButtonVisible : boolean =false;
  isBackButtonVisible : boolean =false;
  isDeleteButtonVisible :boolean =true;

  stages = [{
    id: 1,
    name: 'Backlog',
    cards: ["backlog1","backlog2"],
  }, {
    id: 2,
    name: 'To Do',
    cards: ["todo1","todo2"],
  }, {
    id: 3,
    name: 'Ongoing',
    cards: ["ongoing1","ongoing2"],
  }, {
    id: 4,
    name: 'Done',
    cards: ["done1","done2"],
  }];
 
  constructor() { }

  ngOnInit() {
  }

  onAddCard() {
    let taskName = this.name;
    this.stages[0].cards.push(taskName);
    this.name ='';
  }

  

  onMoveBackCard() {
    let forwardName = this.taskForward;
    let nextStage = this.selectedStage;
    this.stages[nextStage-2].cards.push(forwardName);
    let data = this.stages[this.selectedStage-1].cards;
    let card= data.filter(text => text != forwardName);
    this.stages[this.selectedStage-1].cards = card;
    this.taskForward ='';
    this.isDeleteButtonVisible =true;

  }

  onMoveForwardCard() {
    let forwardName = this.taskForward;
    let nextStage = this.selectedStage;
    this.stages[nextStage].cards.push(forwardName);
    let data = this.stages[this.selectedStage-1].cards;
    let card= data.filter(text => text != forwardName);
    this.stages[this.selectedStage-1].cards = card;
    this.taskForward ='';
    this.isDeleteButtonVisible =true;
  }

  onDeleteCard() {
    let forwardName = this.taskForward;    
    let data = this.stages[this.selectedStage-1].cards;
    let card= data.filter(text => text != forwardName);
    this.stages[this.selectedStage-1].cards = card;
    this.taskForward ='';
    this.isDeleteButtonVisible =true;

  }

  getSelectedValue(data:any){    
    this.selectedStage = data.id;
    this.taskForward = data.text;
    this.isBackButtonVisible =false;
    this.isForwardButtonVisible =false;
    if(data.id > 0 && data.id <=4){
      this.isDeleteButtonVisible =false;
    }
    if(data.id ==1 ){
      this.isBackButtonVisible =true;
    }
    if(data.id ==4){
      this.isForwardButtonVisible =true;
    }
  }




}
