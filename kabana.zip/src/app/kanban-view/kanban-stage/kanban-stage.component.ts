import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-kanban-stage',
  templateUrl: './kanban-stage.component.html',
  styleUrls: ['./kanban-stage.component.css']
})
export class KanbanStageComponent implements OnInit {

  @Input() stage:any;
  @Output() onCardselect: EventEmitter<Object> = new EventEmitter<Object>();
  

  

  constructor() {}

  ngOnInit() {
  }
  getSelectedValue(data:any){
    //console.log(this.stage)
    //console.log(data);
    this.onCardselect.emit({'id':this.stage.id,'text':data});
  }

}
